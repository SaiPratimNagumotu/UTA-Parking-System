package uta_parking.model;

public interface ParkingAreaTestInterface {
	public String validateArea();
	public String validateCapacity();
	public String validateFloor();
	public String validateType();
}
