package uta_parking.model;


//No errors for now. These are error messages that will be used to validate the adding of a parking area by the manager
public class ParkingErrorMsgs {

}
