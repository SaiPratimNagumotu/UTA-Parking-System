package uta_parking.model;

public class SetViolationsErrorMsgs {
	private String search_usernameError;
	
	public SetViolationsErrorMsgs ()
	{
		this.search_usernameError = "";
	}
	
	
	public void setSearch_usernameError(String search_usernameError)
	{this.search_usernameError = search_usernameError;}
	
	
	public String getSearch_usernameError() {
	return search_usernameError;
	}

}
