package uta_parking.tests;

import java.util.regex.Pattern;
import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class LoginSeleniumTest {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  public Properties prop;
  public Properties config;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
	driver = new FirefoxDriver();
    baseUrl = "http://localhost:8080/UTAParking/index.jsp";
    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    config = new Properties();
	prop = new Properties();
	
	config.load(new FileInputStream("./Configuration/HA_Configuration.properties"));
	baseUrl=config.getProperty("sAppURL");
	prop.load(new FileInputStream(config.getProperty("SharedUIMap")));
  }

  @Test
  @FileParameters("src/uta_parking/tests/loginTest.csv")
  public void testLoginSeleniumScript(String userName,String password,String error) throws Exception {
    driver.get(baseUrl + config.getProperty("sIndexPage"));
    driver.findElement(By.name(prop.getProperty("txt_Password"))).clear();
    driver.findElement(By.name(prop.getProperty("txt_UserName"))).clear();
    driver.findElement(By.name(prop.getProperty("txt_UserName"))).sendKeys(userName);
    driver.findElement(By.name(prop.getProperty("txt_Password"))).sendKeys(password);
    driver.findElement(By.name(prop.getProperty("btn_login"))).click();
    if(!error.equals("")) {
    	assertEquals(error, driver.findElement(By.name(prop.getProperty("txt_UserNameError"))).getAttribute("value"));
    }
    else {
    	driver.findElement(By.name(prop.getProperty("btn_logout"))).click();
    }
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
